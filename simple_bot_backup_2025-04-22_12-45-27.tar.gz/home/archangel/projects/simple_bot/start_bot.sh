#!/bin/bash
# Activeer de virtuele omgeving
source /home/archangel/projects/simple_bot/venv/bin/activate
# Start de bot
python3 /home/archangel/projects/simple_bot/simple_chat.py
